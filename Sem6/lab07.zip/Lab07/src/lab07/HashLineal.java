
package lab07;


public class HashLineal {
    private Cliente[] tabla;
    private int capacidad;

    public HashLineal(int capacidad) {
        this.capacidad = capacidad;
        tabla = new Cliente[capacidad];
    }

    public void insertar(Cliente cliente) {
        int idx = hash(cliente.getClave(), capacidad);
        while (tabla[idx] != null) {
            idx = (idx + 1) % capacidad;
        }
        tabla[idx] = cliente;
    }

    public Cliente buscar(String nombres, String apellidos) {
        String clave = nombres.toLowerCase() + apellidos.toLowerCase();
        int idx = hash(clave, capacidad);
        int pasos = 0;
        while (tabla[idx] != null && pasos < capacidad) {
            if (tabla[idx].getClave().equals(clave)) return tabla[idx];
            idx = (idx + 1) % capacidad;
            pasos++;
        }
        return null;
    }
    
    private int hash(String clave, int capacidad) {
    int hash = 7;
    for (int i = 0; i < clave.length(); i++) {
        hash = hash * 31 + clave.charAt(i);
    }
    return Math.abs(hash) % capacidad;
}
}
