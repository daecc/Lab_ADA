
package lab07;


public class NodoArbol {
    Cliente cliente;
    NodoArbol izq, der;

    public NodoArbol(Cliente cliente) {
        this.cliente = cliente;
    }
}
