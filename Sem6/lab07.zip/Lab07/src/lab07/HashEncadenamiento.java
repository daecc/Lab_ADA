
package lab07;

public class HashEncadenamiento {
    private ArbolBinario[] tabla;
    private int capacidad;

    public HashEncadenamiento(int capacidad) {
        this.capacidad = capacidad;
        tabla = new ArbolBinario[capacidad];
        for (int i = 0; i < capacidad; i++)
            tabla[i] = new ArbolBinario();
    }

    public void insertar(Cliente cliente) {
        int idx = hash(cliente.getClave(), capacidad);
        tabla[idx].insertar(cliente);
    }

    public Cliente buscar(String nombres, String apellidos) {
        String clave = nombres.toLowerCase() + apellidos.toLowerCase();
        int idx = hash(clave, capacidad);
        return tabla[idx].buscar(clave);
    }
    
    private int hash(String clave, int capacidad) {
    int hash = 7;
    for (int i = 0; i < clave.length(); i++) {
        hash = hash * 31 + clave.charAt(i);
    }
    return Math.abs(hash) % capacidad;
}
}
