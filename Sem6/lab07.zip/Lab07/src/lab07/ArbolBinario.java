
package lab07;


public class ArbolBinario {
    private NodoArbol raiz;

    public void insertar(Cliente c) {
        raiz = insertarRec(raiz, c);
    }

    private NodoArbol insertarRec(NodoArbol nodo, Cliente c) {
        if (nodo == null) return new NodoArbol(c);
        if (c.getClave().compareTo(nodo.cliente.getClave()) < 0)
            nodo.izq = insertarRec(nodo.izq, c);
        else
            nodo.der = insertarRec(nodo.der, c);
        return nodo;
    }

    public Cliente buscar(String clave) {
        return buscarRec(raiz, clave);
    }

    private Cliente buscarRec(NodoArbol nodo, String clave) {
        if (nodo == null) return null;
        int cmp = clave.compareTo(nodo.cliente.getClave());
        if (cmp == 0) return nodo.cliente;
        return cmp < 0 ? buscarRec(nodo.izq, clave) : buscarRec(nodo.der, clave);
    }
}
