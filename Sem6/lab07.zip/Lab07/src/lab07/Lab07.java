
package lab07;

public class Lab07 {

  
    public static void main(String[] args) {
        new VentanaPrincipal();
    }
    
}
