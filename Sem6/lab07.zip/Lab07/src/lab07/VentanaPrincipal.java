
package lab07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame{
    private JTextField campoNombre, campoApellido, campoTelefono;
    private JButton btnInsertar, btnBuscar;
    private JTextArea areaResultados;

    private HashLineal hashLineal;
    private HashEncadenamiento hashEncadenamiento;

    public VentanaPrincipal() {
        setTitle("Comparación de Métodos Hash");
        setSize(600, 400);
        setLayout(new BorderLayout());

        hashLineal = new HashLineal(101);
        hashEncadenamiento = new HashEncadenamiento(101);

        JPanel panelEntrada = new JPanel(new GridLayout(4, 2));
        campoNombre = new JTextField();
        campoApellido = new JTextField();
        campoTelefono = new JTextField();
        btnInsertar = new JButton("Insertar");
        btnBuscar = new JButton("Buscar");
        areaResultados = new JTextArea();

        panelEntrada.add(new JLabel("Nombres:"));
        panelEntrada.add(campoNombre);
        panelEntrada.add(new JLabel("Apellidos:"));
        panelEntrada.add(campoApellido);
        panelEntrada.add(new JLabel("Teléfono:"));
        panelEntrada.add(campoTelefono);
        panelEntrada.add(btnInsertar);
        panelEntrada.add(btnBuscar);

        add(panelEntrada, BorderLayout.NORTH);
        add(new JScrollPane(areaResultados), BorderLayout.CENTER);

        btnInsertar.addActionListener(e -> insertarCliente());
        btnBuscar.addActionListener(e -> buscarCliente());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void insertarCliente() {
        Cliente c = new Cliente("001", campoNombre.getText(), campoApellido.getText(), campoTelefono.getText(), "", "", "");

        long inicio1 = System.nanoTime();
        hashLineal.insertar(c);
        long fin1 = System.nanoTime();

        long inicio2 = System.nanoTime();
        hashEncadenamiento.insertar(c);
        long fin2 = System.nanoTime();

        areaResultados.append("Insertado cliente.\n");
        areaResultados.append("Tiempo Hash Lineal: " + (fin1 - inicio1) + " ns\n");
        areaResultados.append("Tiempo Encadenamiento (Árbol): " + (fin2 - inicio2) + " ns\n\n");
    }

    private void buscarCliente() {
        String nom = campoNombre.getText();
        String ape = campoApellido.getText();

        long inicio1 = System.nanoTime();
        Cliente c1 = hashLineal.buscar(nom, ape);
        long fin1 = System.nanoTime();

        long inicio2 = System.nanoTime();
        Cliente c2 = hashEncadenamiento.buscar(nom, ape);
        long fin2 = System.nanoTime();

        areaResultados.append("Búsqueda:\n");
        areaResultados.append("Lineal: " + (c1 != null ? c1.toString() : "No encontrado") + " - " + (fin1 - inicio1) + " ns\n");
        areaResultados.append("Encadenado: " + (c2 != null ? c2.toString() : "No encontrado") + " - " + (fin2 - inicio2) + " ns\n\n");
    }
}
