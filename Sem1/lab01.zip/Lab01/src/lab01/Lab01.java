
package lab01;

public class Lab01 {

    static int[][] direcciones = {
        {-1, 0}, // arriba
        {-1, 1}, // diagonal superior derecha
        {0, 1},  // derecha
        {1, 1},  // diagonal inferior derecha
        {1, 0},  // abajo
        {1, -1}, // diagonal inferior izquierda
        {0, -1}, // izquierda
        {-1, -1} // diagonal superior izquierda
    };
    
     public static void main(String[] args) {
        char[][] sopa = {
            {'e', 's', 't', 'o'},
            {'s', 't', 't', 'm'},
            {'e', 'a', 's', 'a'},
            {'p', 'r', 'n', 'e'}
        };

        String[] palabras = {"esto", "ese", "pato", "este"};

        for (String palabra : palabras) {
            if (buscarPalabra(sopa, palabra)) {
                System.out.println("Palabra encontrada: " + palabra);
            } else {
                System.out.println("Palabra no encontrada: " + palabra);
            }
        }
    }
     
     
      public static boolean buscarPalabra(char[][] sopa, String palabra) {
        int filas = sopa.length;
        int columnas = sopa[0].length;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (sopa[i][j] == palabra.charAt(0)) {
                    for (int[] dir : direcciones) {
                        int x = i, y = j, k;

                        for (k = 0; k < palabra.length(); k++) {
                            if (x < 0 || x >= filas || y < 0 || y >= columnas || sopa[x][y] != palabra.charAt(k)) {
                                break;
                            }
                            x += dir[0];
                            y += dir[1];
                        }

                        if (k == palabra.length()) {
                            // Calcular posición final
                            int finX = i + (palabra.length() - 1) * dir[0];
                            int finY = j + (palabra.length() - 1) * dir[1];

                            System.out.println("La palabra '" + palabra + "' comienza en (" + (i + 1) + "," + (j + 1) + ") y termina en (" + (finX + 1) + "," + (finY + 1) + ")");
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
}
