
package recur;
import java.util.Scanner;


public class Principal {

   
    public static void main(String[] args) {
        
        
        Scanner scanner = new Scanner(System.in);
        /*
        Recursividad rc = new Recursividad();
        System.out.println("Ingrese el valor de m: ");
        int m = scanner.nextInt();
        
        System.out.println("Ingrese el valor de n: ");
        int n = scanner.nextInt();
        
        int resultadof = rc.Calcular(m,n);
        
        System.out.println("El valor resultado es: " + resultadof);
        */
        
        
        
        Iterativa it = new Iterativa();
        
        System.out.println("Ingrese el valor de m: ");
        int m = scanner.nextInt();
        
        System.out.println("Ingrese el valor de n: ");
        int n = scanner.nextInt();
        
        int resultadof = it.calcularIterativo(m, n);
        System.out.println("El valor resultado es: " + resultadof);

        
    }
}
