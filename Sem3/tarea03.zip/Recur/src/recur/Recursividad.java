
package recur;

public class Recursividad {
    
    public int Calcular(int m, int n){
        int resultado = 0;
        
        if(m == 0){
            resultado = n+1;
        }
        
        else if(m > 0 & n == 0){
            resultado = Calcular(m-1,1);
            
        }
        
        else if(m > 0 && n > 0){
            resultado = Calcular(m-1,Calcular(m,n-1));
        }
        
        
        return resultado;
    }
    
}
